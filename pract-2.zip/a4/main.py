a = input("введите число от 1 до 1000:" )
b = input("введите число от 1 до 1000:" )
result = [a, b][a <= b]
print(result)
