a=int(input("Введите число А: "))
b=int(input("Введите число В: "))
if a%b == 0:
    print("YES")
else:
    print("NO")